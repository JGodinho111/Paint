package com.example.paint;

import android.graphics.Color;
import android.view.GestureDetector;
import android.view.MotionEvent;

public class GestureListener extends GestureDetector.SimpleOnGestureListener implements GestureDetector.OnDoubleTapListener {

    private PaintCanvas canvas;

    void setCanvas(PaintCanvas canvas) {
        this.canvas = canvas;
    }

    ////////SimpleOnGestureListener
    // Sets Background Color to white
    @Override
    public void onLongPress(MotionEvent motionEvent) {
        //canvas.changeBackground();
        canvas.setBackColor(Color.WHITE);
    }

    /////////OnDoubleTapListener
    // Erases canvas on double tap
    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        canvas.eraseAll();
        return false;
    }
}