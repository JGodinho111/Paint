package com.example.paint;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Splash extends AppCompatActivity {

    // Splash screen timer
    private static int SPLASH_TIME_OUT = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        // Showing splash screen with a timer.
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Splash.this, MainActivity.class);
                startActivity(i);
            }
        }, SPLASH_TIME_OUT); // Timer


        Button mBotao = (Button) findViewById(R.id.button);
        mBotao.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(Splash.this,MainActivity.class));
                //onPause();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first
    }
}

