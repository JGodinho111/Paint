package com.example.paint;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.icu.text.Transliterator;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;

public class MapsFragment extends Fragment {

    //private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    Button mButtonPath;
    View v;
    Polyline polyline = null;
    //List<Polyline> polylineList = new ArrayList<>();
    List<LatLng> latLngList = new ArrayList<>();
    //List<Location> locationList = new ArrayList<>();

    private OnMapReadyCallback callback = new OnMapReadyCallback() {

        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        @SuppressLint("MissingPermission")
        @Override
        public void onMapReady(GoogleMap googleMap) {
            //LatLng portugal = new LatLng(38.7050180, -9.2860001);
            //googleMap.addMarker(new MarkerOptions().position(portugal).title("Marker on Me!"));
            //googleMap.moveCamera(CameraUpdateFactory.newLatLng(portugal));
            //enableMyLocation(googleMap);

            mButtonPath = (Button) v.findViewById(R.id.button10);
            googleMap.setMyLocationEnabled(true);
            if (googleMap != null) {
                googleMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
                    @Override
                    public void onMyLocationChange(Location arg0) {
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(arg0.getLatitude(), arg0.getLongitude()),24.0f));
                        if(mButtonPath.getText().equals("Stop Drawing")){
                            // Não a solução idela pois assim se parar e recomeçar a desenhar
                            //  o ultimo ponto da linha vai ser conectado ao primeiro dos novos
                            //locationList.add(arg0);
                            latLngList.add(new LatLng(arg0.getLatitude(),arg0.getLongitude()));
                            PolylineOptions polylineOptions = new PolylineOptions().addAll(latLngList).clickable(true);
                            polyline = googleMap.addPolyline(polylineOptions);
                            //polylineList.add(polyline);
                        }
                        if(mButtonPath.getText().equals("Start Drawing")){
                            // do nothing
                        }
                    }
                });
            }
            //googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(portugal.latitude, portugal.longitude), 18.0f));
            mButtonPath.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mButtonPath.getText().equals("Start Drawing")){
                        //startDrawing(view, googleMap);
                        mButtonPath.setText("Stop Drawing");
                    } else if(mButtonPath.getText().equals("Stop Drawing")){
                        //stopDrawing(view, googleMap);
                        mButtonPath.setText("Start Drawing");
                    }else{
                        //ignore
                    }
                }
            });
        }
    };

    /*
    private void startDrawing(View view, GoogleMap googleMap) {
        //TODO
        googleMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location arg0) {
                //locationList.add(arg0);
                latLngList.add(new LatLng(arg0.getLatitude(),arg0.getLongitude()));
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(arg0.getLatitude(), arg0.getLongitude()),18.0f));
            }
        });
        PolylineOptions polylineOptions = new PolylineOptions().addAll(latLngList).clickable(true);
        polyline = googleMap.addPolyline(polylineOptions);
    }

    private void stopDrawing(View view, GoogleMap googleMap) {
        //TODO
        googleMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location arg0) {
                //googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(arg0.getLatitude(), arg0.getLongitude()),18.0f));
            }
        });
    }
    */

    /*
    private void enableMyLocation(GoogleMap googleMap) {
        // [START maps_check_location_permission]
        if (ContextCompat.checkSelfPermission(googleMap., Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (googleMap != null) {
                googleMap.setMyLocationEnabled(true);
            }
        } else {
            // Permission to access the location is missing. Show rationale and request permission
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        }
        // [END maps_check_location_permission]
    }
    */

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        v =  inflater.inflate(R.layout.fragment_maps, container, false);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }
}