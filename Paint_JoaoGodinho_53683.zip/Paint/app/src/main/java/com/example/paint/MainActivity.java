package com.example.paint;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    public PaintCanvas paintCanvas;
    public FragmentManager fragmentManager = getSupportFragmentManager();
    private int appBackrgoundColor;
    int orientation;
    FloatingActionButton mBotaoPalette;
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    private static final int MIN_TIME_BETWEEN_SHAKES_MILLISECS = 1000;
    private long mLastShakeTime;
    private SensorManager sensorMgr;
    private float mLightQuantity;
    private static final double SHAKE_THRESHOLD = 20;

    // For Firebase Storage
    ImageView imageView;
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        appBackrgoundColor = R.color.white;
        // Call method that asks permission
        askPermission(this);
        mLastShakeTime = 0;

        // Request permission for location - directly from Android Studio Website on asking for location permision
        ActivityResultLauncher<String[]> locationPermissionRequest =
                registerForActivityResult(new ActivityResultContracts
                                .RequestMultiplePermissions(), result -> {
                    Boolean fineLocationGranted = null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        fineLocationGranted = result.getOrDefault( //will not work on API level lower than 24, project minimum is 21
                                Manifest.permission.ACCESS_FINE_LOCATION, false);
                    }
                    Boolean coarseLocationGranted = null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        coarseLocationGranted = result.getOrDefault( //will not work on API level lower than 24, project minimum is 21
                                Manifest.permission.ACCESS_COARSE_LOCATION,false);
                    }
                    if (fineLocationGranted != null && fineLocationGranted) {
                                // Precise location access granted.
                            } else if (coarseLocationGranted != null && coarseLocationGranted) {
                                // Only approximate location access granted.
                            } else {
                                // No location access granted.
                            }
                        }
                );

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------

        // Before you perform the actual permission request, check whether your app
        // already has the permissions, and whether your app needs to show a permission
        // rationale dialog. For more details, see Request permissions.
        locationPermissionRequest.launch(new String[] {
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        });

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------
        //PaintCanvas setup
        GestureListener mGestureListener = new GestureListener();
        GestureDetector mGestureDetector = new GestureDetector(getApplicationContext(), mGestureListener);
        mGestureDetector.setIsLongpressEnabled(true); // changes background to white on long press
        mGestureDetector.setOnDoubleTapListener(mGestureListener); //"erases" paint strokes

        paintCanvas = new PaintCanvas(getApplicationContext(), null, mGestureDetector);
        mGestureListener.setCanvas(paintCanvas);
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------
        sensorMgr = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorMgr.registerListener(listenerTwo, sensorMgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);
        sensorMgr.registerListener(listenerOne, sensorMgr.getDefaultSensor(Sensor.TYPE_LIGHT), SensorManager.SENSOR_DELAY_FASTEST);
        sensorMgr.registerListener(listenerThree, sensorMgr.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------
        //Menu Buttons

        Button mBotaoSettings = (Button) findViewById(R.id.button2);
        mBotaoSettings.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //startActivity(new Intent(MainActivity.this,SettingsActivity.class));
                orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(false);
                }
                Fragment fragment = new SettingsFragment();
                FragmentManager fm = fragmentManager;
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.replace(R.id.canvas,fragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        Button mBotaoAbout = (Button) findViewById(R.id.button3);
        mBotaoAbout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //startActivity(new Intent(MainActivity.this,AboutActivity.class));
                orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(false);
                }
                Fragment fragment = new AboutFragment();
                FragmentManager fm = fragmentManager;
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.replace(R.id.canvas, fragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        Button mBotaoMain = (Button) findViewById(R.id.button5);
        mBotaoMain.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //startActivity(new Intent(MainActivity.this,MainActivity.class));
                //myFragment != null &&
                orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(true);
                }
                Fragment fragment = new CanvasFragment();
                FragmentManager fm = fragmentManager;
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.replace(R.id.canvas, fragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        // If location permissions were denied app will crash
        Button mBotaoMap = (Button) findViewById(R.id.button8);
        mBotaoMap.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(false);
                }
                Fragment fragment = new MapsFragment();
                FragmentManager fm = fragmentManager;
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.replace(R.id.canvas, fragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        // Floating Button for Palette in Portrait mode
        orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                mBotaoPalette.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Fragment fragment = new PaletteFragment();
                        FragmentManager fm = fragmentManager;
                        FragmentTransaction transaction = fm.beginTransaction();
                        transaction.replace(R.id.canvas, fragment);
                        transaction.addToBackStack(null);
                        transaction.commit();
                    }
                });
        }
    }
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    public int getAppBackrgoundColor (){
        return appBackrgoundColor;
    }
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Asking for writing permissions - to be able to change screen brightness
    public void askPermission(Context c){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if(Settings.System.canWrite(c)){
                // We have permissions to write settings
            }
            else{
                // Ask permission to write settings
                Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                c.startActivity(i);
            }
        }
    }

    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    SensorEventListener listenerOne = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
           mLightQuantity = event.values[0];
            if(mLightQuantity < 30){
                // Brightness varia entre 0 e 255
                Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS, 240);
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    // Após um shake deveria apagar tudo, mas as vezes requer um toque no ecrã após o shake
    SensorEventListener listenerTwo = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if(event.sensor!= null && event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
                    long curTime = java.lang.System.currentTimeMillis();
                    if ((curTime - mLastShakeTime) > MIN_TIME_BETWEEN_SHAKES_MILLISECS) {

                        float tx = event.values[0];
                        float ty = event.values[1];
                        float tz = event.values[2];

                        double acceleration = Math.sqrt(
                                Math.pow(tx, 2) +
                                Math.pow(ty, 2) +
                                Math.pow(tz, 2)
                        ) - SensorManager.GRAVITY_EARTH;

                        if (acceleration > SHAKE_THRESHOLD) {
                            mLastShakeTime = curTime;
                            paintCanvas.eraseAll();
                        }
                    }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    // Sensor que deteta mudanças nos eixos - apenas funciona no emulador
    SensorEventListener listenerThree = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor!= null && event.sensor.getType() == Sensor.TYPE_GYROSCOPE){
                if(event.values[0] > 0.5f || event.values[1] > 0.5f || event.values[2] > 0.5f){ //anti-clockwise
                    paintCanvas.changeBackground();
                }if(event.values[0] < -0.5f || event.values[1] < -0.5f || event.values[2] < -0.5f ){ //clockwise
                    paintCanvas.changeBackground();
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    //---------------------------------------------------------------------------------------------------------------------------------------------------------------

    @Override
    protected void onResume() {
        super.onResume();
        sensorMgr.registerListener(listenerOne, sensorMgr.getDefaultSensor(Sensor.TYPE_LIGHT), SensorManager.SENSOR_DELAY_FASTEST);
        sensorMgr.registerListener(listenerTwo, sensorMgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);
        sensorMgr.registerListener(listenerThree, sensorMgr.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorMgr.unregisterListener(listenerOne);
        sensorMgr.unregisterListener(listenerTwo);
        sensorMgr.unregisterListener(listenerThree);
    }

    //---------------------------------------------------------------------------------------------------------------------------------------------------------------
    //Menu (3 dots - does the same thing as the topbar aka menu buttons)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View view = this.getWindow().getDecorView();
        orientation = getResources().getConfiguration().orientation;

        // Handle item selection
        switch (item.getItemId()) {
            case R.id.home:
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(true);
                }
                Fragment fragment = new CanvasFragment();
                FragmentManager fm = fragmentManager;
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.replace(R.id.canvas, fragment);
                transaction.addToBackStack(null);
                transaction.commit();
                return true;
            case R.id.save_painting:
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(true);
                }

                // Storing the canvas as an image and sending it to the firebase cloud storage - not working

                //if(fragmentManager.findFragmentById(R.id.canvas).isInLayout()){
                /*

                    imageView = findViewById(R.id.imageToSend);
                    // Criar um bitmap do canvas
                    Bitmap bitmap = Bitmap.createBitmap(imageView.getWidth(),imageView.getHeight(),Bitmap.Config.ARGB_8888);
                    Canvas imageCnvs = new Canvas(bitmap);
                    //imageView.setImageBitmap(bitmap);
                    imageView.draw(imageCnvs);
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG,100, outputStream);
                    byte[] data = outputStream.toByteArray();

                    String path = "paintimage/" + UUID.randomUUID() + ".png";
                    StorageReference paintimageRef = storage.getReference(path);
                    //StorageMetadata metadata = new StorageMetadata().b
                    UploadTask uploadTask = paintimageRef.putBytes(data);

                    uploadTask.addOnFailureListener(MainActivity.this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.i("F-UPLD", "Upload Task Failed");
                        }
                    });
                    uploadTask.addOnCanceledListener(MainActivity.this, new OnCanceledListener() {
                        @Override
                        public void onCanceled() {
                            Log.i("C-UPLD", "Upload Task Canceled!");

                        }
                    });
                    uploadTask.addOnCompleteListener(MainActivity.this, new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            Log.i("S-UPLD", "Upload Task Complete!");
                        }
                    });
                */
                //}
                return true;

            case R.id.open:
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(true);
                }
                // Abrir desenhos da firebase - não implementado
                // O meu raciocínio era ir buscar a imagen à cloud e defini-la como o background do paintCanvas
                return true;
            case R.id.settings:
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(false);
                }
                Fragment fragmentSt = new SettingsFragment();
                FragmentManager fmst = fragmentManager;
                FragmentTransaction transactionSt = fmst.beginTransaction();
                transactionSt.replace(R.id.canvas,fragmentSt);
                transactionSt.addToBackStack(null);
                transactionSt.commit();
                return true;
            case R.id.about:
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(false);
                }
                Fragment fragmentAb = new AboutFragment();
                FragmentManager fma = fragmentManager;
                FragmentTransaction transactionAb = fma.beginTransaction();
                transactionAb.replace(R.id.canvas, fragmentAb);
                transactionAb.addToBackStack(null);
                transactionAb.commit();
                return true;
            case R.id.map:
                // If location permissions were denied app will crash
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    mBotaoPalette = (FloatingActionButton) findViewById(R.id.floatingActionButton);
                    mBotaoPalette.setEnabled(false);
                }
                Fragment fragmentMp = new MapsFragment();
                FragmentManager fmp = fragmentManager;
                FragmentTransaction transactionMp = fmp.beginTransaction();
                transactionMp.replace(R.id.canvas, fragmentMp);
                transactionMp.addToBackStack(null);
                transactionMp.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //---------------------------------------------------------------------------------------------------------------------------------------------------------------

    //Not used anymore - old way to change background color to "dark mode" with the use of the now unused settings activity
    /*
    public void swapColor(View v){
        View view = this.getWindow().getDecorView();
        ColorDrawable colored = (ColorDrawable) view.getBackground();
        int color = colored.getColor();
        Button b4 = (Button) findViewById(R.id.button4);

        if(color == getResources().getColor(R.color.white)){
            view.setBackgroundColor(getResources().getColor(R.color.SlateGray));
            b4.setTextColor(getResources().getColor(R.color.LightSteelBlue));
        } else{
            view.setBackgroundColor(getResources().getColor(R.color.white));
            b4.setTextColor(getResources().getColor(R.color.white));
        }
        //setContentView(R.layout.activity_main);
    }

    public void onClick2(View v) {
        setContentView(R.layout.activity_settings);

        View view = this.getWindow().getDecorView();
        ColorDrawable colored = (ColorDrawable) view.getBackground();
        int color = colored.getColor();

        Button b4 = (Button) findViewById(R.id.button4);

        if(color == getResources().getColor(R.color.white)){
            b4.setTextColor(getResources().getColor(R.color.white));
        } else{
            b4.setTextColor(getResources().getColor(R.color.LightSteelBlue));
        }
    }

    public void onClick3(View v) {
        setContentView(R.layout.activity_about);

        View view = this.getWindow().getDecorView();
        ColorDrawable colored = (ColorDrawable) view.getBackground();
        int color = colored.getColor();

        if(color == getResources().getColor(R.color.white)){
            TextView t2 = findViewById(R.id.textView2);
            t2.setTextColor(getResources().getColor(R.color.gray));

            TextView t3 = findViewById(R.id.textView3);
            t3.setTextColor(getResources().getColor(R.color.gray));

            TextView t4 = findViewById(R.id.textView4);
            t4.setTextColor(getResources().getColor(R.color.gray));

            TextView t5 = findViewById(R.id.textView5);
            t5.setTextColor(getResources().getColor(R.color.gray));

            TextView t6 = findViewById(R.id.textView6);
            t6.setTextColor(getResources().getColor(R.color.gray));
        }
        else{
            TextView t2 = findViewById(R.id.textView2);
            t2.setTextColor(getResources().getColor(R.color.LightSteelBlue));

            TextView t3 = findViewById(R.id.textView3);
            t3.setTextColor(getResources().getColor(R.color.LightSteelBlue));

            TextView t4 = findViewById(R.id.textView4);
            t4.setTextColor(getResources().getColor(R.color.LightSteelBlue));

            TextView t5 = findViewById(R.id.textView5);
            t5.setTextColor(getResources().getColor(R.color.LightSteelBlue));

            TextView t6 = findViewById(R.id.textView6);
            t6.setTextColor(getResources().getColor(R.color.LightSteelBlue));
        }
    }

    public void onClick5(View v) {
        setContentView(R.layout.activity_main);
    }
     */
}