package com.example.paint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// NO LONGER IN USE
public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        /*
        Button mBotaoSettings = (Button) findViewById(R.id.button2);
        mBotaoSettings.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(SettingsActivity.this,SettingsActivity.class));
                //onPause();
            }
        });

        Button mBotaoAbout = (Button) findViewById(R.id.button3);
        mBotaoAbout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(SettingsActivity.this,AboutActivity.class));
                //onPause();
            }
        });

        Button mBotaoMain = (Button) findViewById(R.id.button5);
        mBotaoMain.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(SettingsActivity.this,MainActivity.class));
                //onPause();
            }
        });

         */
    }

    /*
    public void swapColor(View v){
        View view = this.getWindow().getDecorView();
        ColorDrawable colored = (ColorDrawable) view.getBackground();
        int color = colored.getColor();
        Button b4 = (Button) findViewById(R.id.button4);

        if(color == getResources().getColor(R.color.white)){
            view.setBackgroundColor(getResources().getColor(R.color.SlateGray));
            b4.setTextColor(getResources().getColor(R.color.LightSteelBlue));
        } else{
            view.setBackgroundColor(getResources().getColor(R.color.white));
            b4.setTextColor(getResources().getColor(R.color.white));
        }
        //setContentView(R.layout.activity_main);
    }
     */
}