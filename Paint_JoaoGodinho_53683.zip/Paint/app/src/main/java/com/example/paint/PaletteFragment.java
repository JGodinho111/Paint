package com.example.paint;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import yuku.ambilwarna.AmbilWarnaDialog;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PaletteFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PaletteFragment extends Fragment{

    int mDefaultColor;
    Button mButtonPick;
    Button mButtonBackGround;
    View returnView;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public PaletteFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PaletteFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static PaletteFragment newInstance(String param1, String param2) {
        PaletteFragment fragment = new PaletteFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

   public void openColorPicker(View view){
        // initialColor is the initially-selected color to be shown in the rectangle on the left of the arrow.
        // for example, 0xff000000 is black, 0xff0000ff is blue. Please be aware of the initial 0xff which is the alpha.
        AmbilWarnaDialog colorPicker = new AmbilWarnaDialog(view.getContext(), mDefaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                // color is the color selected by the user.
                mDefaultColor = color;

                int orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    ((MainActivity) getActivity()).paintCanvas.setPaintColor(mDefaultColor);
                    Fragment replacementFragment = new CanvasFragment();
                    FragmentManager fm = ((MainActivity)getActivity()).fragmentManager;
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.canvas,replacementFragment);
                    ft.addToBackStack(null);
                    ft.commit();
                }
                else{
                    ((MainActivity) getActivity()).paintCanvas.setPaintColor(mDefaultColor);
                }
            }

            @Override
            public void onCancel(AmbilWarnaDialog dialog) {
                // cancel was selected by the user
            }
        });
        mDefaultColor = colorPicker.hashCode();

        colorPicker.show();
    }


    private void openColorPicker2(View view) {
        AmbilWarnaDialog colorPicker = new AmbilWarnaDialog(view.getContext(), mDefaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                // color is the color selected by the user.
                mDefaultColor = color;

                int orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    ((MainActivity) getActivity()).paintCanvas.setBackColor(mDefaultColor);
                    Fragment replacementFragment = new CanvasFragment();
                    FragmentManager fm = ((MainActivity)getActivity()).fragmentManager;
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.canvas,replacementFragment);
                    ft.addToBackStack(null);
                    ft.commit();
                }
                else{
                    ((MainActivity) getActivity()).paintCanvas.setBackColor(mDefaultColor);
                }
            }

            @Override
            public void onCancel(AmbilWarnaDialog dialog) {
                // cancel was selected by the user
            }
        });
        mDefaultColor = colorPicker.hashCode();

        colorPicker.show();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        returnView = inflater.inflate(R.layout.fragment_palette, container, false);

        mDefaultColor = ContextCompat.getColor(returnView.getContext(), R.color.white);
        //ContextCompat.getColor(v.getContext(), R.color.design_default_color_primary);
        mButtonPick = (Button) returnView.findViewById(R.id.button6);
        mButtonPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openColorPicker(view);
            }
        });
        mButtonBackGround = (Button) returnView.findViewById(R.id.button7);
        mButtonBackGround.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openColorPicker2(view);
            }
        });
        return returnView;
    }

            /* An older way I tried using for color picker
        imgView = getActivity().findViewById(R.id.colorPickers);
        mColorValues = getActivity().findViewById(R.id.displayValues);
        mColorViews = getActivity().findViewById(R.id.displayColors);

        imgView.setDrawingCacheEnabled(true);
        imgView.buildDrawingCache(true);


        imgView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN || motionEvent.getAction() == MotionEvent.ACTION_MOVE){
                    bitmap = imgView.getDrawingCache();
                    int pixels = bitmap.getPixel((int) motionEvent.getX(), (int) motionEvent.getY());

                    int r = Color.red(pixels);
                    int g = Color.green(pixels);
                    int b = Color.blue(pixels);

                    String hex = "#" +  Integer.toHexString(pixels);
                    mColorViews.setBackgroundColor(Color.rgb(r,g,b));
                    mColorValues.setText("RGB: " + r + ", " + g + ", " + b + " \nHEX: " + hex);
                }
                return true;
            }
        });
        */
}