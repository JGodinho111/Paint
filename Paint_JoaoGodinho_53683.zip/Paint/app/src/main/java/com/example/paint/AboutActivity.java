package com.example.paint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// NO LONGER IN USE
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        /*
        Button mBotaoSettings = (Button) findViewById(R.id.button2);
        mBotaoSettings.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(AboutActivity.this,SettingsActivity.class));
                //onPause();
            }
        });

        Button mBotaoAbout = (Button) findViewById(R.id.button3);
        mBotaoAbout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(AboutActivity.this,AboutActivity.class));
                //onPause();
            }
        });

        Button mBotaoMain = (Button) findViewById(R.id.button5);
        mBotaoMain.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //setContentView(R.layout.activity_main);
                startActivity(new Intent(AboutActivity.this,MainActivity.class));
                //onPause();
            }
        });
         */
    }
}