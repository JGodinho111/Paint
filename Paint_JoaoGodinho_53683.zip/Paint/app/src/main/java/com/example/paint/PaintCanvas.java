package com.example.paint;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

public class PaintCanvas extends View implements View.OnTouchListener{

    private Paint paint = new Paint();
    private Path path = new Path();
    private static int backGroundColor = Color.WHITE;
    private GestureDetector mGestureDetector;

    private static ArrayList<Path> pathList = new ArrayList<>();
    private static ArrayList<Paint> paintList = new ArrayList<>();
    private ArrayList<Integer> backgroundColors = new ArrayList<>();

    public PaintCanvas(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOnTouchListener(this);
        setBackgroundColor(backGroundColor);
        initPaint();
    }

    public PaintCanvas(Context context, AttributeSet attrs, GestureDetector mGestureDetector) {
        super(context, attrs);
        this.mGestureDetector = mGestureDetector;
        setOnTouchListener(this);
        setBackgroundColor(backGroundColor);
        initPaint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //canvas.drawPath(path, paint);// draws the path with the paint
        for(int i=0; i < pathList.size(); i++){
            canvas.drawPath(pathList.get(i),paintList.get(i));
        }
    }

    @Override
    public boolean performClick(){
        return super.performClick();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        mGestureDetector.onTouchEvent(event);
        return false; // let the event go to the rest of the listeners
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float eventX = event.getX();
        float eventY = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(eventX, eventY);// updates the path initial point

                pathList.add(path);
                paintList.add(paint);
                backgroundColors.add(backGroundColor);

                return true;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(eventX, eventY);// makes a line to the point each time this event is fired

                pathList.add(path);
                paintList.add(paint);
                backgroundColors.add(backGroundColor);

                break;
            case MotionEvent.ACTION_UP:// when you lift your finger
                performClick();
                break;
            default:
                return false;
        }

        // Schedules a repaint.
        invalidate();
        return true;
    }

    public void changeBackground(){
        Random r = new Random();
        backGroundColor = Color.rgb(r.nextInt(256), r.nextInt(256), r.nextInt(256));
        setBackgroundColor(backGroundColor);
    }

    public void erase(){
        paint.setColor(backGroundColor);
    }

    private void initPaint(){
        paint.setAntiAlias(true);
        paint.setStrokeWidth(20f);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setBackColor(int color){
        backGroundColor = color;
        for(int i= 0; i < paintList.size(); i++){
            if(paintList.get(i).getColor() == backGroundColor){
                paintList.get(i).setColor(color);
            }
        }
        setBackgroundColor(color);
    }

    public int getBackColor(){
        return backGroundColor;
    }

    public void setPaintColor(int color){
        pathList.add(path);
        paintList.add(paint);
        backgroundColors.add(backGroundColor);
        path = new Path();
        paint = new Paint();
        initPaint();
        paint.setColor(color);
    }

    public int getPaintColor(){
        return paint.getColor();
    }

    // V1 - changes the paint list to be the same as the background
    public void eraseAll(){
        for(int i= 0; i < paintList.size(); i++){
            paintList.get(i).setColor(backGroundColor);
        }
        setPaintColor(R.color.Black);
    }

    // V2 - Clears the path and paint list and resets the paint color to black (however it seems to take 2 shakes)
    // --> One shake takes opacity down and second shake removes pathlist
    /*
    public void eraseAll(){
        pathList.clear();
        paintList.clear();
        setPaintColor(R.color.Black);
    }
    */
}
